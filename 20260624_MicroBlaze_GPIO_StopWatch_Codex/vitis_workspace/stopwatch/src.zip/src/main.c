#include "xil_printf.h"
#include "common/delay/delay.h"
#include "ap/StopWatch.h"
//#include "driver/LED/LED.h"
//#include "driver/FND/FND.h"
//#include "driver/Button/Button.h"



int main() {

   int counter = 0;
   uint16_t ledState = 1;

   uint32_t curTime, prevTime;

   while (1) {

	   StopWatch_Excute();

//      if (Button_GetState(&hbtnRunStop) == ACT_RELEASED) {
//         LED_PinToggle(0);
//      }
//      if (Button_GetState(&hbtnClear) == ACT_PUSHED) {
//         LED_PinToggle(2);
//      }
      //curTime = millis();
      //if (curTime - prevTime >= 100 - 1) {
      //   prevTime = curTime;

      //   xil_printf("counter = %d\n", counter++);

      //   ledState = (ledState >> 1) | (ledState << 15);
      //   LED_WritePort16(ledState);

      //   FND_SetNum(counter++);
      //}

      // polling service routine
      FND_Excute();
      incTick();
      delay_ms(1);
   }
   return 0;
}
