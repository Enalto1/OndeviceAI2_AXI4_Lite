/*
 * StopWatch.c
 *
 *  Created on: 2026. 6. 24.
 *      Author: kccistc
 */

#include "StopWatch.h"

stopWatch_e stopWatchState;
uint32_t counter;

void StopWatch_Init()
{
	LED_Init();
	FND_Init();
	Button_Init();

	stopWatchState = STOP;
	counter = 0;
}

void StopWatch_Excute()
{
	StopWatch_RunTime();
	StopWatch_ControlState();
	FND_SetNum(counter);
}

void StopWatch_ControlState()
{
	switch (stopWatchState){
	case STOP:
		if(Button_GetState(&hbtnRunStop) == ACT_PUSHED){
			stopWatchState = RUN;
		}
		break;
	case RUN:
		if(Button_GetState(&hbtnRunStop) == ACT_PUSHED){
			stopWatchState = CLEAR;
		}
		break;
	case CLEAR:
		stopWatchState = STOP;
		counter = 0;
		break;
	default:
		stopWatchState = STOP;
		break;
	}
}

void StopWatch_RunTime()
{
	static uint32_t prevTime = 0;
	uint32_t curTime = millis();

	if(curTime - prevTime < 100) return;
	prevTime = curTime;

	if(stopWatchState == RUN){
		counter ++;
	}
}
